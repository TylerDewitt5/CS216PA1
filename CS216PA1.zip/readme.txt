g++ -o CS216PA1 main.cpp
