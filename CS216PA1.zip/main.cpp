//course: CS216-002
//project: project assignment 1
//date: 2/25/2017
//purpose: To take an input of text file of actors and movies they are in and based on the user input print out either (A) all the actors that are in either of the two movies the user entered, (C) all the actors in both of the movies, (O) all the actors in one movie but not both, or all the co-actors of in each movie of the actor entered
//name: Tyler Dewitt

#include <iostream>
#include <fstream>
#include <map> 
#include <set>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;
set<string> mov_set(string movie, ifstream& PA1movies);
set<string> symetric_diff(set<string> mov1_set, set<string> mov2_set);
set<string> set_union(set<string> movie1, set<string> movie2);
set<string> intersection(set<string> mov1_set, set<string> mov2_set);
map<string, set<string> > mapping_actors(ifstream& PA1movies);

int main(int argc, char* argv[])
{
	if (argc != 2)
	{
		cout << "warning: need exactly one command line argument" << endl;
		cout << "usage: " << argv[0] << " PA1movies.txt" << endl;
		return 1;
	}
	ifstream PA1movies;
	PA1movies.open(argv[1]);
	if (!PA1movies.is_open())
	{		
		cout << "File did not open" << endl; 
		return 0;
	}
	string choice;
	string movie1;
	string movie2;
	string actor1;
	cout << "This application stores information about Actors and their Movies, please choose your option (Enter Q or q to quit):\n1.Actors in Movies\n2.Actors and co-stars " << endl;
	cin >> choice;
	while (choice != "Q" && choice != "q")
	{
	
		if (choice == "1")
		{
			cout <<	"Please input the first movie title: " << endl;
			cin.ignore();
			getline(cin, movie1);
			cout << "Please input the second movie title: " << endl;
			cin.ignore();
			getline(cin, movie2);
			bool mov1_found = false;
			bool mov2_found = false;
			string::size_type n_mov1 = 0;
			string::size_type n_mov2 = 0;
			PA1movies.clear();
			PA1movies.seekg(0, ios::beg);
			while (!PA1movies.eof())
			{
				string line;
				while(getline(PA1movies, line))
				{
					n_mov1 = line.find(movie1, 0);
					if (n_mov1 != string::npos)
					{
						mov1_found = true;
					}
					n_mov2 = line.find(movie1, 0);
					if (n_mov2 != string::npos)
					{
						mov2_found = true;
					}
				}
			}
			if (mov1_found == true && mov2_found == true)
			{
				cout << "Both movies are in the database, please continue... " << endl;
			}
			else
			{
				cout << "Both movies are not in the database" << endl;
				return 0;
			}
		
			cout << "Please enter your menu option(Enter Q or q to quit)\nA -- to pring all the actors in either of the two movies.\nC -- to print all of the common actors in both of the moives.\nO -- to print all the actors who are in one movie but not both. " << endl;
			string choice2;
			cin >> choice2;
			while (choice2 != "Q" && choice2 != "q")
			{
				set<string> movie1_actors = mov_set(movie1, PA1movies);
				set<string> movie2_actors = mov_set(movie2, PA1movies);
					

				if (choice2 == "A" || choice2 == "a")
				{
				
					set<string> mov12_union = set_union(movie1_actors, movie2_actors);			
					cout << "All the actors in either of the two movies:" << endl;
					for (set<string>::iterator i = mov12_union.begin(); i != mov12_union.end(); i++)
        				{
                				
                				cout << *i  << endl;
        				}

				}
				else if (choice2 == "C" || choice2 == "c")
				{
				
					set<string> mov12_intersection = intersection(movie1_actors, movie2_actors);
					cout << "Common actors in both movies: " << endl;
					for (set<string>::iterator i = mov12_intersection.begin(); i != mov12_intersection.end(); i++)
        				{
                				
                				cout << *i << endl;
        				}

				}
				else if (choice2 == "O" || choice2 == "o")
				{
					set<string> mov12_symdiff = symetric_diff(movie1_actors, movie2_actors);
					cout << "Actors only in one of the two movies:" << endl;
					for (set<string>::iterator i = mov12_symdiff.begin(); i != mov12_symdiff.end(); i++)
       					{
                		
                				cout << *i << endl;
        				}


				}		
				else
				{
					cout << "Invalid option" << endl;
                       		}
				cout << "Please enter your menu option(Enter Q or q to quit)\nA -- to pring all the actors in either of the two movies.\nC -- to print all of the common actors in both of the moives.\nO -- to print all the actors who are in one movie but not both. " << endl;
                                cin >> choice2;	
			}
		}
		else if(choice == "2")
		{
			cout << "choice 2 selected" << endl;
			cout << "Find the co-actors of the actor by typing his/her name: " << endl;
			cin.ignore();
			getline(cin, actor1);
			bool act1_found = false;
                        string::size_type n_act1 = 0;
			PA1movies.clear();
                        PA1movies.seekg(0, ios::beg);
			while (!PA1movies.eof())
                        {
                                string line;
                                while(getline(PA1movies, line))
                                {
                                        n_act1 = line.find(actor1, 0);
                                        if (n_act1 != string::npos)
                                        {
                                                act1_found = true;
                                        }
                                }
                        }
			if (act1_found == true)
			{
				
				map<string, set<string> > map_of_actors = mapping_actors(PA1movies);
				set<string> actor1_set;
				for(map<string, set<string> >::iterator i = map_of_actors.begin(); i != map_of_actors.end(); i++)
				{
					if (i->first == actor1) //iterate through map until actor that user entered is foun
					{
						actor1_set = i->second; // set the input actor set
					}
				}
				
				for(set<string>::iterator i = actor1_set.begin(); i != actor1_set.end(); i++)
				{
					// iterate through each movie of the actor entered
					vector<string> actor_vect;
					string movie_name = *i;
					for(map<string, set<string> >::iterator q = map_of_actors.begin(); q != map_of_actors.end(); q++)
					{
						
						for(set<string>::iterator z = q->second.begin(); z != q->second.end(); z++) 
						{
							//iterate through map again and look for all other actors 							   in the same movies as inputed actor name
							if(movie_name == *z && q->first != actor1)
							{
								// add found co-stars to vector for each movie
								actor_vect.push_back(q->first);
							}
						}
					}
					cout << "The co_actors of " << actor1 << " in the movie \"" << movie_name << "\" are: " << endl;
					for (int k = 0; k < actor_vect.size(); k++)
					{
						cout << actor_vect[k] << endl; // print out all the co-stars for 										   each movie
					}
					cout << "*****************************************" << endl;
				}
			} 
			else 
			{
				cout << "The actor name you entered is not in the database." << endl;
			}
			

		}
		else
		{
			cout << "Invalid option" << endl;
		}
		cout << "This application stores information about Actors and their Movies, please choose your option (Enter Q or q to quit):\n1.Actors in Movies\n2.Actors and co-stars " << endl;
                cin >> choice;

	}
	cout << "Thank you for using my program, bye..." << endl;
	PA1movies.close();
	return 0;
}


/* The mov_set function takes a movie title entered by the user and searches the   input file for all the actors who are in the movie 
   and inserts them into a set, which the function then returns */
set<string> mov_set(string movie, ifstream& PA1movies) 
{

	set<string> actors;
	actors.clear();
	PA1movies.clear();  // this in conjunction with the next line makes 
	PA1movies.seekg(0, ios::beg);// sure the file starts from beginning
	while(!PA1movies.eof())
	{
		string::size_type find_movie = 0; // holds position of movie
		string::size_type find_comma = 0; // holds position of first comma in the line
		string line;
		while (getline(PA1movies, line)) //reads through fille line-by-line and puts in line variable
		{
			find_movie = line.find(movie); 
			if (find_movie != string::npos) // statement is only true if movie was found in line 
			{
				find_comma = line.find(',' , 0); // find first comma position
				string actor_name = line.substr(0, find_comma); // actors name will be all string										    from 0 position to position of										     first comma
				actors.insert(actor_name); 
			}
		}
	}


	return actors;
}

/* Takes a set of all the actors in the first movie and all the actors in the second movie
   and puts them all together into one set, making sure that if an actor is in both movies 
   that that actor's name is only inserted once. This set is then returned. */
set<string> set_union(set<string> mov1_set, set<string> mov2_set)
{
	set<string> union_of;
	for (set<string>::iterator i = mov1_set.begin(); i != mov1_set.end(); i++)
        {
		// iterates through all the actors of the first movie and puts them into union set
		union_of.insert(*i);
        }
	for (set<string>::iterator q = mov2_set.begin(); q != mov2_set.end(); q++)
        {
                // iterates through all actors of second movie	
        	if (union_of.count(*q) > 0) // makes sure same actor isn't added twice
                {
		}
		else
		{
			union_of.insert(*q); 
		}	
	}
	

	return union_of;
}

/* taking all the actors of the first movie in a set and all the actors of he second movie in a set
   this function stores finds all the actors who are in both movies and puts them into a set
   to be returned */ 
set<string> intersection(set<string> mov1_set, set<string> mov2_set)
{
	set<string> inter_of; // intersection of movies 1 and 2
	for (set<string>::iterator i = mov1_set.begin(); i != mov1_set.end(); i++)
        {
                
                for (set<string>::iterator q = mov2_set.begin(); q != mov2_set.end(); q++)
                {
                        // for each actor in movie 1, this iterates through all the actors in movie 2 to compare
                        if (*i == *q) // only adds actor to set if actor is in both movies
                        {
				inter_of.insert(*q);
                        }
                        else
                        {
                        }
                }
        }
	
	return inter_of;
}

/* Function takes a set of all the actors in movie 1 and a set of all the actors in movie 2
   and puts all the actors who are in one movie but not both into a set that is returned.
   All the actors in only one movie is the union of actors in both movies minus the intersection
   of actors in both movie, so all the actors that are in the union of the two movies are inserted
   into the return set and all the actors that are in the intersection of the two movies are removed
   from the return set */
   
set<string> symetric_diff(set<string> mov1_set, set<string> mov2_set)
{
	set<string> sym_diff_of;
	set<string> union_of_sets = set_union(mov1_set, mov2_set);
	set<string> inter_of_sets = intersection(mov1_set, mov2_set);
	for (set<string>::iterator i = union_of_sets.begin(); i != union_of_sets.end(); i++)
	{
		sym_diff_of.insert(*i); // adds all the movies that are in the union
	}
	for (set<string>::iterator q = inter_of_sets.begin(); q != inter_of_sets.end(); q++)
	{

		sym_diff_of.erase(*q); // removes all movies that are in the intersection
	}
	return sym_diff_of;
}	

/* maps each actor to set of all the movies he or she has been in and then returns this map */

map<string, set<string> > mapping_actors(ifstream& PA1movies)
{
	map<string, set<string> > actor_map;
        set<string> movies;
	PA1movies.clear();
        PA1movies.seekg(0, ios::beg);
	while(!PA1movies.eof())
        {
	
		string line;
		movies.clear(); // makes sure to reset the set of movies for each new actor/line
		getline(PA1movies, line);
		string name, movie;  
		istringstream iss(line); 
		getline(iss, name, ','); // gets actor name from line
		iss >> ws;
		while (getline(iss, movie, ',')) // separates all the movies by comma
		{
			iss >> ws;
			movies.insert(movie); // put each movie for an actor in a set
		}
		actor_map[name] = movies; // assign actor and set of his/her movies in the map
	}

	return actor_map;
}


